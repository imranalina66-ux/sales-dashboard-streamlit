import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Title
st.title("Sales Dashboard")

# Load data
df = pd.read_csv("sales_data.csv")
st.write("### Data Preview")
st.dataframe(df.head())

# Summary
st.write("### Summary Statistics")
st.write(df.describe())

# Plot total sales by product
st.write("### Total Sales by Product")
sales_by_product = df.groupby('Product')['Sales'].sum()
fig1, ax1 = plt.subplots()
sales_by_product.plot(kind='bar', ax=ax1)
plt.ylabel("Total Sales")
st.pyplot(fig1)

# Plot sales over time
st.write("### Sales Over Time")
if 'Date' in df.columns:
    df['Date'] = pd.to_datetime(df['Date'])
    sales_over_time = df.groupby('Date')['Sales'].sum()
    fig2, ax2 = plt.subplots()
    sales_over_time.plot(ax=ax2)
    plt.ylabel("Sales")
    plt.xlabel("Date")
    st.pyplot(fig2)
