# Sales Dashboard

This is a Streamlit dashboard for analyzing sales data.

## How to run locally
```
pip install -r requirements.txt
streamlit run dashboard.py
```

## Files
- dashboard.py → Streamlit app
- sales_data.csv → sample data
- requirements.txt → dependencies
