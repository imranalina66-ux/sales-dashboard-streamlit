
import streamlit as st
import pandas as pd

st.title('Sales Dashboard')

# Load CSV files
df_sales = pd.read_csv('sales_data.csv')
st.subheader('Sales Data')
st.dataframe(df_sales)

# If employee_data.csv exists
try:
    df_emp = pd.read_csv('employee_data.csv')
    st.subheader('Employee Data')
    st.dataframe(df_emp)
except FileNotFoundError:
    st.info('employee_data.csv not found')
