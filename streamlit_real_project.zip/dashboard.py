
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title('Sales & Employee Dashboard')

# Load CSV files
df_sales = pd.read_csv('sales_data.csv')
df_emp = pd.read_csv('employee_data.csv')

# Sales Data Table
st.subheader('Sales Data')
st.dataframe(df_sales)

# Employee Data Table
st.subheader('Employee Data')
st.dataframe(df_emp)

# Sales by Product Bar Chart
st.subheader('Sales by Product')
sales_by_product = df_sales.groupby('Product')['Sales'].sum().reset_index()
st.bar_chart(sales_by_product.set_index('Product'))

# Sales Filter by Region
region = st.selectbox('Select Region', df_sales['Region'].unique())
filtered = df_sales[df_sales['Region']==region]
st.subheader(f'Sales Data for Region: {region}')
st.dataframe(filtered)
